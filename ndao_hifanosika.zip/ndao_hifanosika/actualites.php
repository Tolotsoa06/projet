<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualités</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/flaticons/font/flaticon.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="assets/img/ndao_hifanosika.png" type="image/x-icon">
</head>

<body>
    <header role="banner">
        <nav class="navbar navbar-expand-md" id="menu">
            <div class="container">
                <a class="navbar-brand" href="index.php"><img src="assets/img/ndao_hifanosika.png" width="55px" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-navicon"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbar">
                    <ul class="navbar-nav ml-auto pl-lg-5 pl-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php#apropos">A propos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="evenement.php">Evènements</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="indx.php#contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <section class="home-slider owl-carousel">

    </section>
    <section class="section element-animate">

        <div class="clearfix mb-5 pb-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 text-center heading-wrap">
                        <h2>Nos Actualités</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid" id="actualite">
        </div>
    </section>



    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/html.js"></script>
    <script src="assets/js/function.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/pages/actualites.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/magnific-popup-options.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require('PHPMailer/src/PHPMailer.php');
    require('PHPMailer/src/SMTP.php');
    require('PHPMailer/src/Exception.php');
    
    $subject = $_POST['sujet'];
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $mail = new PHPMailer();

    $mail->isSMTP();
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->SMTPAuth = true;
    $mail->Username = 'kifraemit@gmail.com';
    $mail->Password = 'Ubisoft06';
    $mail->setFrom('kifraemit@gmail.com');
    $mail->addAddress('franckiantenaina@gmail.com');
    $mail->addReplyTo($email, $nom);
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = $message;
    if($mail->send()){
        echo json_encode(array(
            'type'=>'success',
            'contenu' => 'Merci de nous avoir contacté! Nous allons repondre votre message dès que possible'
        ));
    }else{
        echo json_encode(array(
            'type'=>'error',
            'contenu' => 'Echec de l\'envoie du message '
        ));
    }
?>
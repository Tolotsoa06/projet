<?php
    //declaration des variables de la connexion
    $host = "localhost";
    $database = "ndao_hifanosika";
    $username = "root";
    $password = "";
    //initialiser la connexion au base
    $db = mysqli_connect($host,$username,$password,$database) or die('Impossible de se connecter au base de données : '.mysqli_connect_error());
?>
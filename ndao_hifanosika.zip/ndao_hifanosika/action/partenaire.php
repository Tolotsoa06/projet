<?php
    include('connexiondb.php');
    include('constant.php');


    if(isset($_POST['getAll'])){
        $sql = "SELECT * FROM partenaire";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output[] = array(
                'nom' => $row['nom'],
                'site_web' => $row['site_web'],
                'image' => IMAGE_PARTENAIRE.$row['image']
            );
        }
        echo json_encode($output);
    }
?>
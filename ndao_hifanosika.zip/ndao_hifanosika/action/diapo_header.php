<?php
    include('constant.php');
    include('connexiondb.php');
    if(isset($_POST['getHeader'])){
        $sql = "SELECT * FROM diapo_header";
        $sql_execute = mysqli_query($db,$sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output[] = array(
                'id_diapo_header' => $row['id_diapo_header'],
                'titre' => $row['titre'],
                'image' => IMAGE_DIAPO.$row['image'],
                'texte' => $row['texte']
            );
        }
        echo json_encode($output);
    }
?>
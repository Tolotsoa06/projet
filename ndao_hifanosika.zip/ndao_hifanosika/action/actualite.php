<?php
    include('connexiondb.php');
    include('constant.php');
    setlocale(LC_ALL, 'fr_FR.utf8','fra');
    if(isset($_POST['getActualite'])){
        $sql = "SELECT * FROM actualite ORDER BY created_at DESC LIMIT 4";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output[] = array(
                'id_actualite' => $row['id_actualite'],
                'titre' => $row['titre'],
                'contenu' => $row['contenu'],
                'image' => IMAGE_ACTUALITE.$row['image']
            );
        }
        echo json_encode($output);
    }

    if(isset($_POST['getOne'])){
        $id = $_POST['id_actualite'];
        $sql = "SELECT * FROM actualite WHERE (id_actualite = $id)";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output = array(
                'id_actualite' => $row['id_actualite'],
                'titre' => $row['titre'],
                'contenu' => $row['contenu'],
                'image' => IMAGE_ACTUALITE.$row['image'],
                'date' => ucfirst(strftime("%A %d %B %Y à %H : %M",strtotime($row['created_at'])))
            );
        }
        echo json_encode($output);
    }

    if(isset($_POST['getAll'])){
        $sql = "SELECT * FROM actualite";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output[] = array(
                'id_actualite' => $row['id_actualite'],
                'titre' => $row['titre'],
                'contenu' => $row['contenu'],
                'image' => IMAGE_ACTUALITE.$row['image'],
                'date' => ucfirst(strftime("%A %d %B %Y à %H : %M",strtotime($row['created_at'])))
            );
        }
        echo json_encode($output);
    }
?>
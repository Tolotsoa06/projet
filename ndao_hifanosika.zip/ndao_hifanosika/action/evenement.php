<?php
    include('connexiondb.php');
    include('constant.php');
    setlocale(LC_ALL, 'fr_FR.utf8','fra');
    if(isset($_POST['getAll'])){
        $sql = "SELECT * FROM evenement";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output[] = array(
                'id_evenement' => $row['id_evenement'],
                'titre' => $row['titre'],
                'description' => $row['description'],
                'image' => IMAGE_EVENEMENT.$row['image'],
                'date_debut' => ucfirst(strftime("%A %d %B %Y à %H : %M",strtotime($row['date_debut']))),
                'date_fin' => ucfirst(strftime("%A %d %B %Y à %H : %M",strtotime($row['date_fin'])))
            );
        }
        echo json_encode($output);
    }
?>
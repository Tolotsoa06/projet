<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>Authentification</title><!-- plugins:css -->
    <link rel="stylesheet" href="css/css-materialdesignicons.css">
    <link rel="stylesheet" href="css/css-vendor.addons.css"><!-- endinject -->
    <!-- vendor css for this page -->
    <!-- End vendor css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="css/shared-style.css"><!-- endinject -->
    <!-- Layout style -->
    <link rel="stylesheet" href="css/demo_1-style.css"><!-- Layout style -->
    <link rel="shortcut icon" href="images/ndao_hifanosika.png">
</head>

<body>
    <div class="authentication-theme auth-style_1">
        <div class="row">
            <div class="col-12 logo-section">
                <a href="#" class="logo">
                    <img src="images/ndao_hifanosika.png" alt="logo">
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-5 col-md-7 col-sm-9 col-11 mx-auto">
                <div class="grid">
                    <div class="grid-body">
                        <div class="row">
                            <div class="col-lg-7 col-md-8 col-sm-9 col-12 mx-auto form-wrapper">
                                <form id="loginForm">
                                    <div class="message">
                                        <div class="alert alert-danger dismissible-alert" role="alert" style="display: none;">
                                            <p></p>
                                        </div>
                                    </div>
                                    <div class="form-group input-rounded">
                                        <input type="text" class="form-control" name="email" id="email" placeholder="Adresse mail ou Nom d'utilisateur">
                                    </div>
                                    <div class="form-group input-rounded">
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Mot de passe">
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-block">S'authentifier</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="auth_footer">
            <p class="text-muted text-center">© <a href="http://arato.mg" target="blank">ARATO</a> <script>document.write(new Date().getFullYear())</script></p>
        </div>
    </div>
    <!--page body ends -->
    <!-- SCRIPT LOADING START FORM HERE /////////////-->
    <!-- plugins:js -->
    <script src="js/js-core.js"></script>
    <script src="js/js-vendor.addons.js"></script><!-- endinject -->
    <!-- Vendor Js For This Page Ends-->
    <!-- Vendor Js For This Page Ends-->
    <script src="js/js-script.js"></script>
    <script src="js/login.js"></script>
</body>

</html>
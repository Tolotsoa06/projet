<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>Ndao hifanosika Fianara Administrateur</title><!-- plugins:css -->
    <link rel="stylesheet" href="css/css-materialdesignicons.css">
    <link rel="stylesheet" href="css/css-flag-icon.css">
    <link rel="stylesheet" href="css/css-vendor.addons.css"><!-- endinject -->
    <!-- vendor css for this page -->
    <!-- End vendor css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="css/shared-style.css"><!-- endinject -->
    <!-- Layout style -->
    <link rel="stylesheet" href="css/demo_1-style.css"><!-- Layout style -->
    <link rel="shortcut icon" href="images/ndao_hifanosika.png">
</head>

<body class="header-fixed">
    <!-- partial:partials/_header.html -->
    <nav class="t-header">
        <div class="t-header-brand-wrapper">
            <a href="index.php">
                <img class="logo" src="images/ndao_hifanosika.png" alt="">
                <img class="logo-mini" src="images/ndao_hifanosika.png" alt="">
            </a>
            <button class="t-header-toggler t-header-desk-toggler d-none d-lg-block">
                <svg class="logo" viewbox="0 0 200 200">
                    <path class="top" d="M 40, 80 C 40, 80 120, 80 140, 80 C180, 80 180, 20  90, 80 C 60,100  30,120  30,120"></path>
                    <path class="middle" d="M 40,100 L140,100"></path>
                    <path class="bottom" d="M 40,120 C 40,120 120,120 140,120 C180,120 180,180  90,120 C 60,100  30, 80  30, 80"></path>
                </svg>
            </button>
        </div>
        <div class="t-header-content-wrapper">
            <div class="t-header-content">
                <button class="t-header-toggler t-header-mobile-toggler d-block d-lg-none">
                    <i class="mdi mdi-menu"></i>
                </button>
                <ul class="nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link" href="#" id="appsDropdown" data-toggle="dropdown" aria-expanded="false">
                            <i class="mdi mdi-arrow-down-drop-circle mdi-1x"></i>
                        </a>
                        <div class="dropdown-menu navbar-dropdown dropdown-menu-right" aria-labelledby="appsDropdown">
                            <div class="dropdown-header">
                                <h6 class="dropdown-title">Profiles</h6>
                            </div>
                            <div class="dropdown-body border-top pt-0">
                                <a href="#" class="d-flex logOut">
                                    <i class="mdi mdi-logout mdi-2x"></i>
                                    <span class="grid-tittle">Se deconnecter</span>
                                </a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav><!-- partial -->
    <div class="page-body">
        <!-- partial:partials/_sidebar.html -->
        <div class="sidebar">
            <div class="user-profile">
                <div class="display-avatar animated-avatar">
                    <img class="profile-img img-lg rounded-circle" src="" alt="">
                </div>
                <div class="info-wrapper">
                    <p class="user-name"></p>
                </div>
            </div>
            <ul class="navigation-menu">
                <li class="nav-category-divider">Menu</li>
                <li>
                    <a href="index.php">
                        <span class="link-title">Dashboard</span>
                        <i class="mdi mdi-gauge link-icon"></i>
                    </a>
                </li>
                <li>
                    <a href="actualite.php">
                        <span class="link-title">Actualité</span>
                        <i class="mdi mdi-newspaper link-icon"></i> 
                    </a>
                </li>
                <li>
                    <a href="evenement.php">
                        <span class="link-title">Evènements</span>
                        <i class="mdi mdi-calendar link-icon"></i> 
                    </a>
                </li>
                <li>
                    <a href="administrateur.php">
                        <span class="link-title">Administrateur</span>
                        <i class="mdi mdi-account link-icon"></i> 
                    </a>
                </li>
                <li>
                    <a href="partenaire.php">
                        <span class="link-title">Partenaire</span>
                        <i class="mdi mdi-account-multiple-outline link-icon"></i>
                    </a>
                </li>
                <li>
                    <a href="header.php">
                        <span class="link-title">Header</span>
                        <i class="mdi mdi-file-image link-icon"></i>
                    </a>
                </li>
            </ul>
        </div>

        <div class="page-content-wrapper">
            <div class="page-content-wrapper-inner">
                <div class="content-viewport">
                    
                </div>
            </div><!-- content viewport ends -->
            <!-- partial:partials/_footer.html -->
            <footer class="footer">
                <div class="row">
                    <div class="col-sm-6 text-center text-sm-left mt-3 mt-sm-0">
                        <small class="text-muted d-block">Copyright &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://arato.mg" target="_blank">ARATO</a>. <span class="bg-dark"><i class="flag-icon flag-icon-mg"></i></span></small>
                    </div>
                </div>
            </footer><!-- partial -->
        </div><!-- page content ends -->
    </div>
    <!--page body ends -->
    <!-- SCRIPT LOADING START FORM HERE /////////////-->
    <!-- plugins:js -->
    <script src="js/js-core.js"></script>
    <script src="js/js-vendor.addons.js"></script><!-- endinject -->
    <!-- Vendor Js For This Page Ends-->
    <script src="js/apexcharts-apexcharts.min.js"></script>
    <script src="js/chartjs-Chart.min.js"></script>
    <script src="js/charts-chartjs.addon.js"></script><!-- Vendor Js For This Page Ends-->
    <script src="js/js-script.js"></script>
    <script src="js/index.js"></script>
</body>

</html>
<?php
    include('connexionDB.php');
    include('constant.php');

    if(isset($_GET['liste'])){
        $sql = "SELECT * FROM diapo_header";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $action = "<div class='btn btn-rounded social-icon-btn btn-danger' onclick=\"supprimer('".$row['id_diapo_header']."')\"><i class='mdi mdi-trash-can-outline'></i></div>";
            $output['data'][] = array(
                'titre' => $row['titre'],
                'texte' => $row['texte'],
                'image' => "<img src='".IMAGE_DIAPO.$row['image']."' class='img-xxl'>",
                'action' => $action
            );
        }
        echo json_encode($output);
    }


    if(isset($_POST['supprimer'])){
        $sql = "SELECT * FROM diapo_header WHERE id_diapo_header=".$_POST['id'];
        $query= mysqli_query($db, $sql);
        $header = mysqli_fetch_assoc($query);
        unlink('../../images/header/'.$header['image']);
        $sql_delete = "DELETE FROM diapo_header WHERE id_diapo_header = ".$_POST['id'];
        echo json_encode(mysqli_query($db,$sql_delete));
    }
?>
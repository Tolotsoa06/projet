<?php 
    include('connexionDB.php');
    include('constant.php');

    if(isset($_GET['liste'])){
        $sql = "SELECT * FROM partenaire";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $action = "<div class='btn btn-rounded social-icon-btn btn-danger' onclick=\"supprimer('".$row['id_partenaire']."')\"><i class='mdi mdi-trash-can-outline'></i></div>";
            $output['data'][] = array(
                'nom' => $row['nom'],
                'site' => $row['site_web'],
                'image' => "<img src='".IMAGE_PARTENAIRE.$row['image']."' class='img-xl'>",
                'action' => $action
            );
        }
        echo json_encode($output);
    }

    if(isset($_POST['supprimer'])){
        $sql = "SELECT * FROM partenaire WHERE id_partenaire=".$_POST['id'];
        $query= mysqli_query($db, $sql);
        $partenaire = mysqli_fetch_assoc($query);
        unlink('../../images/partenaire/'.$partenaire['image']);
        $sql_delete = "DELETE FROM partenaire WHERE id_partenaire = ".$_POST['id'];
        echo json_encode(mysqli_query($db,$sql_delete));
    }
?>
<?php
    include('connexionDB.php');
    include('constant.php');

    move_uploaded_file($_FILES["image"]["tmp_name"], "../../images/header/".$_FILES["image"]["name"]);
    $titre = str_replace("'","''",$_POST['titre']);
    $texte = str_replace("'","''",$_POST['texte']);
    $image = str_replace("'","''",$_FILES['image']['name']);
    $sql = "INSERT INTO `diapo_header`(`titre`, `texte`, `image`) VALUES ('$titre', '$texte','$image')";
    $sql_execute = mysqli_query($db, $sql);
    echo json_encode($sql_execute);
        
?>
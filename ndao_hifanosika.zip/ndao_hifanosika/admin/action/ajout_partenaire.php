<?php
    include('connexionDB.php');
    include('constant.php');

    move_uploaded_file($_FILES["image"]["tmp_name"], "../../images/partenaire/".$_FILES["image"]["name"]);
    $nom = str_replace("'","''",$_POST['nom']);
    $site = str_replace("'","''",$_POST['site']);
    $image = str_replace("'","''",$_FILES['image']['name']);
    $sql = "INSERT INTO `partenaire`(`nom`, `site_web`, `image`) VALUES ('$nom', '$site','$image')";
    $sql_execute = mysqli_query($db, $sql);
    echo json_encode($sql_execute);
    
?>
<?php
    include('connexionDB.php');
    include('constant.php');

    $email = $_POST['email'];
    $mdp = md5($_POST['password']);
    $sql = "SELECT * FROM administrateur WHERE ((email = '$email') OR (username = '$email')) AND (password = '$mdp')";
    $run_sql = mysqli_query($db, $sql);
    if(mysqli_num_rows($run_sql) == 1){
        $admin = mysqli_fetch_assoc($run_sql);
        $output = array(
            'nom' => $admin['nom'],
            'id' => $admin['id_administrateur'],
            'token' => $admin['token']
        );
    }else{
        $output = "Adresse email ou Nom d'utilisateur ou Mot de passe incorrect";
    }
    echo json_encode($output);
?>
<?php
    include('connexionDB.php');
    include('constant.php');

    if(isset($_GET['liste'])){
        $sql = "SELECT * FROM actualite ORDER BY created_at DESC";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $action = "<div class='btn btn-rounded social-icon-btn btn-info mr-3' onclick=\"detail('".$row['id_actualite']."')\"><i class='mdi mdi mdi-information-outline'></i></div><div class='btn btn-rounded social-icon-btn btn-danger' onclick=\"supprimer('".$row['id_actualite']."')\"><i class='mdi mdi-trash-can-outline'></i></div>";
            $output['data'][] = array(
                'titre' => $row['titre'],
                'contenue' => $row['contenu'],
                'image' => "<img src='".IMAGE_ACTUALITE.$row['image']."' class='img-md'>",
                'action' => $action
            );
        }
        echo json_encode($output);  
    }

    if(isset($_POST['detail'])){
        $sql = "SELECT * FROM actualite WHERE id_actualite=".$_POST['id'];
        $sql_execute = mysqli_query($db, $sql);
        $actualite = mysqli_fetch_assoc($sql_execute);
        $actualite['image'] = IMAGE_ACTUALITE.$actualite['image'];
        echo json_encode($actualite);
    }

    if(isset($_POST['supprimer'])){
        $sql = "SELECT * FROM actualite WHERE id_actualite=".$_POST['id'];
        $query= mysqli_query($db, $sql);
        $actualite = mysqli_fetch_assoc($query);
        unlink('../../images/actualite/'.$actualite['image']);
        $sql_delete = "DELETE FROM actualite WHERE id_actualite=".$_POST['id'];
        $sql_execute = mysqli_query($db, $sql_delete);
        echo json_encode($sql_execute);
    }
?>

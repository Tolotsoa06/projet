<?php
    include('connexionDB.php');
    include('constant.php');

    if(isset($_POST['id'])){
        $id = $_POST['id'];
        $sql = "SELECT * FROM administrateur WHERE id_administrateur = $id";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $output = array(
                'id' => $row['id_administrateur'],
                'nom' => $row['nom'],
                'token' => $row['token'],
                'avatar' => AVATAR.$row['avatar']
            );
        }
        echo json_encode($output);
    }

    if(isset($_GET['liste'])){
        $sql = "SELECT * FROM administrateur";
        $sql_execute = mysqli_query($db,$sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $action = "<div class='btn btn-rounded social-icon-btn btn-danger' onclick=\"supprimer('".$row['id_administrateur']."')\"><i class='mdi mdi-trash-can-outline'></i></div>";
            $output['data'][] = array(
                'nom' => $row['nom'],
                'email' => $row['email'],
                'username' => $row['username'],
                'avatar' => "<img src='".AVATAR.$row['avatar']."' class='img-md rounded-circle'>",
                'action' => $action
            );
        }
        echo json_encode($output);
    }

    if(isset($_POST['supprimer'])){
        $id = $_POST['id_admin'];
        echo json_encode(mysqli_query($db, "DELETE FROM administrateur WHERE id_administrateur = $id"));
    }
?>
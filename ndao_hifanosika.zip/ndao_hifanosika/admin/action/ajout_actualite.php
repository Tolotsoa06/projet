<?php
    include('connexionDB.php');
    include('constant.php');

    move_uploaded_file($_FILES["image"]["tmp_name"], "../../images/actualite/".$_FILES["image"]["name"]);
    $titre = str_replace("'","''",$_POST['titre']);
    $contenu = str_replace("'","''",$_POST['contenue']);
    $image = str_replace("'","''",$_FILES['image']['name']);
    
    $sql = "INSERT INTO `actualite`( `image`, `titre`, `contenu`, `created_at`) VALUES ('$image', '$titre', '$contenu', CURRENT_TIMESTAMP())";
    $sql_execute = mysqli_query($db, $sql);
    echo json_encode($sql_execute);
    
?>
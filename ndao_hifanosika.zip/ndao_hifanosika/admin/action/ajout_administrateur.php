<?php
    include('connexionDB.php');
    include('constant.php');

    move_uploaded_file($_FILES["image"]["tmp_name"], "../images/".$_FILES["image"]["name"]);
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $image = $_FILES['image']['name'];
    $username = $_POST['username'];
    $mdp = md5($_POST['password']);
    $token = md5($nom);
    $sql = "INSERT INTO `administrateur`(`nom`, `email`, `username`, `password`, `token`, `avatar`) VALUES ('$nom', '$email','$username', '$password', '$token', '$image')";
    $sql_execute = mysqli_query($db, $sql);
    echo json_encode($sql_execute);
    
?>
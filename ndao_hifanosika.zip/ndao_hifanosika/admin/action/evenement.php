<?php 
    include('connexionDB.php');
    include('constant.php');
    setlocale(LC_ALL, 'fr_FR.utf8', 'fra');
    if(isset($_GET['liste'])){
        $sql = "SELECT * FROM evenement";
        $sql_execute = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($sql_execute)) {
            $action = "<div class='btn btn-rounded social-icon-btn btn-danger' onclick=\"supprimer('".$row['id_evenement']."')\"><i class='mdi mdi-trash-can-outline'></i></div>";
            $output['data'][] = array(
                'titre' => $row['titre'],
                'description' => $row['description'],
                'image' => "<img src='".IMAGE_EVENEMENT.$row['image']."' class='img-xxl'>",
                'debut' => ucfirst(strftime("%d %B %Y à %H : %M",strtotime($row['date_debut']))),
                'fin' => ucfirst(strftime("%d %B %Y à %H : %M",strtotime($row['date_fin']))),
                'action' => $action
            );
        }
        echo json_encode($output);
    }

    if(isset($_POST['supprimer'])){
        $sql = "SELECT * FROM evenement WHERE id_evenement=".$_POST['id'];
        $query= mysqli_query($db, $sql);
        $evenement = mysqli_fetch_assoc($query);
        unlink('../../images/evenement/'.$evenement['image']);
        $sql_delete = "DELETE FROM evenement WHERE id_evenement = ".$_POST['id'];
        echo json_encode(mysqli_query($db,$sql_delete));
    }
?>
<?php
    define('URL', 'http://'.$_SERVER['HTTP_HOST'].'/ndao_hifanosika/');
    define('IMAGE_DIAPO', 'http://'.$_SERVER['HTTP_HOST'].'/ndao_hifanosika/images/header/');
    define('AVATAR', 'http://'.$_SERVER['HTTP_HOST'].'/ndao_hifanosika/admin/images/');
    define('IMAGE_ACTUALITE', 'http://'.$_SERVER['HTTP_HOST'].'/ndao_hifanosika/images/actualite/');
    define('IMAGE_EVENEMENT', 'http://'.$_SERVER['HTTP_HOST'].'/ndao_hifanosika/images/evenement/');
    define('IMAGE_PARTENAIRE', 'http://'.$_SERVER['HTTP_HOST'].'/ndao_hifanosika/images/partenaire/');
?>
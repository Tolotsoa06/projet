<?php
    include('connexionDB.php');
    include('constant.php');

    move_uploaded_file($_FILES["image"]["tmp_name"], "../../images/evenement/".$_FILES["image"]["name"]);
    $titre = str_replace("'","''",$_POST['titre']);
    $description = str_replace("'","''",$_POST['description']);
    $image = str_replace("'","''",$_FILES['image']['name']);
    $debut = $_POST['date_debut']." ".$_POST['heure_debut'];
    $fin = $_POST['date_fin']." ".$_POST['heure_fin'];
    $sql = "INSERT INTO `evenement`(`titre`, `description`, `image`, `date_debut`, `date_fin`) VALUES ('$titre', '$description','$image', '$debut', '$fin')";
    $sql_execute = mysqli_query($db, $sql);
    echo json_encode($sql_execute);
    
?>
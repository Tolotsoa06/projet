<!DOCTYPE html>
<html lang="en-US">
<head>
				
			<meta property="og:url" content="https://uxcandy.co/demo/label_pro/preview/assets/js/highlight.pack.js"/>
			<meta property="og:type" content="article"/>
			<meta property="og:title" content="Uxcandy"/>
			<meta property="og:description" content="Premium Responsive Admin Dashboard Template"/>
			<meta property="og:image" content="https://uxcandy.co/demo/wp-content/themes/foton/assets/img/open_graph.jpg"/>
		
		
		<meta charset="UTF-8"/>
		<link rel="profile" href="https://gmpg.org/xfn/11"/>
		
				<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
		<title>Page not found - Uxcandy</title>

<!-- This site is optimized with the Yoast SEO Premium plugin v11.4 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Uxcandy" />
<meta property="og:site_name" content="Uxcandy" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - Uxcandy" />
<script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://uxcandy.co/#organization","name":"Ux Candy","url":"https://uxcandy.co/","sameAs":["https://www.facebook.com/uxcandylab/"],"logo":{"@type":"ImageObject","@id":"https://uxcandy.co/#logo","url":"https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png","width":327,"height":60,"caption":"Ux Candy"},"image":{"@id":"https://uxcandy.co/#logo"}},{"@type":"WebSite","@id":"https://uxcandy.co/#website","url":"https://uxcandy.co/","name":"Uxcandy","publisher":{"@id":"https://uxcandy.co/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://uxcandy.co/?s={search_term_string}","query-input":"required name=search_term_string"}}]}</script>
<!-- / Yoast SEO Premium plugin. -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Uxcandy &raquo; Feed" href="https://uxcandy.co/feed/" />
<link rel="alternate" type="application/rss+xml" title="Uxcandy &raquo; Comments Feed" href="https://uxcandy.co/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v7.10.4 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	var mi_version         = '7.10.4';
	var mi_track_user      = true;
	var mi_no_track_reason = '';
	
	var disableStr = 'ga-disable-UA-133737599-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
	
	if ( mi_track_user ) {
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

		__gaTracker('create', 'UA-133737599-1', 'auto');
		__gaTracker('set', 'forceSSL', true);
		__gaTracker('require', 'displayfeatures');
		__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
	} else {
		console.log( "" );
		(function() {
			/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
			var noopfn = function() {
				return null;
			};
			var noopnullfn = function() {
				return null;
			};
			var Tracker = function() {
				return null;
			};
			var p = Tracker.prototype;
			p.get = noopfn;
			p.set = noopfn;
			p.send = noopfn;
			var __gaTracker = function() {
				var len = arguments.length;
				if ( len === 0 ) {
					return;
				}
				var f = arguments[len-1];
				if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
					console.log( 'Not running function __gaTracker(' + arguments[0] + " ....) because you are not being tracked. " + mi_no_track_reason );
					return;
				}
				try {
					f.hitCallback();
				} catch (ex) {

				}
			};
			__gaTracker.create = function() {
				return new Tracker();
			};
			__gaTracker.getByName = noopnullfn;
			__gaTracker.getAll = function() {
				return [];
			};
			__gaTracker.remove = noopfn;
			window['__gaTracker'] = __gaTracker;
					})();
		}
</script>
<!-- / Google Analytics by MonsterInsights -->
<link   rel='stylesheet' id='wp-block-library-css'  href='https://uxcandy.co/wp-includes/css/dist/block-library/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='wc-block-style-css'  href='https://uxcandy.co/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.5.11' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link   rel='stylesheet' id='wc-gateway-ppec-frontend-css'  href='https://uxcandy.co/wp-content/plugins/woocommerce-gateway-paypal-express-checkout/assets/css/wc-gateway-ppec-frontend.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-default-style-css'  href='https://uxcandy.co/wp-content/themes/foton/style.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-modules-css'  href='https://uxcandy.co/wp-content/themes/foton/assets/css/modules.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-dripicons-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/dripicons/dripicons.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-font_elegant-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/elegant-icons/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-font_awesome-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/font-awesome/css/fontawesome-all.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-ion_icons-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/ion-icons/css/ionicons.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-linea_icons-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/linea-icons/style.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-linear_icons-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/linear-icons/style.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-simple_line_icons-css'  href='https://uxcandy.co/wp-content/themes/foton/framework/lib/icons-pack/simple-line-icons/simple-line-icons.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='mediaelement-css'  href='https://uxcandy.co/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.13-9993131' type='text/css' media='all' />
<link   rel='stylesheet' id='wp-mediaelement-css'  href='https://uxcandy.co/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-woo-css'  href='https://uxcandy.co/wp-content/themes/foton/assets/css/woocommerce.min.css?ver=5.4.2' type='text/css' media='all' />
<style id='foton-mikado-woo-inline-css' type='text/css'>
.mkdf-st-loader .mkdf-rotate-circles > div, .mkdf-st-loader .pulse, .mkdf-st-loader .double_pulse .double-bounce1, .mkdf-st-loader .double_pulse .double-bounce2, .mkdf-st-loader .cube, .mkdf-st-loader .rotating_cubes .cube1, .mkdf-st-loader .rotating_cubes .cube2, .mkdf-st-loader .stripes > div, .mkdf-st-loader .wave > div, .mkdf-st-loader .two_rotating_circles .dot1, .mkdf-st-loader .two_rotating_circles .dot2, .mkdf-st-loader .five_rotating_circles .container1 > div, .mkdf-st-loader .five_rotating_circles .container2 > div, .mkdf-st-loader .five_rotating_circles .container3 > div, .mkdf-st-loader .atom .ball-1:before, .mkdf-st-loader .atom .ball-2:before, .mkdf-st-loader .atom .ball-3:before, .mkdf-st-loader .atom .ball-4:before, .mkdf-st-loader .clock .ball:before, .mkdf-st-loader .mitosis .ball, .mkdf-st-loader .lines .line1, .mkdf-st-loader .lines .line2, .mkdf-st-loader .lines .line3, .mkdf-st-loader .lines .line4, .mkdf-st-loader .fussion .ball, .mkdf-st-loader .fussion .ball-1, .mkdf-st-loader .fussion .ball-2, .mkdf-st-loader .fussion .ball-3, .mkdf-st-loader .fussion .ball-4, .mkdf-st-loader .wave_circles .ball, .mkdf-st-loader .pulse_circles .ball, .mkdf-st-loader .mkdf-logo-letter-holder .mkdf-logo-letter-bgrnd { background-color: #1e73be;}
</style>
<link   rel='stylesheet' id='foton-mikado-woo-responsive-css'  href='https://uxcandy.co/wp-content/themes/foton/assets/css/woocommerce-responsive.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-style-dynamic-css'  href='https://uxcandy.co/wp-content/themes/foton/assets/css/style_dynamic.css?ver=1582324786' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-modules-responsive-css'  href='https://uxcandy.co/wp-content/themes/foton/assets/css/modules-responsive.min.css?ver=5.4.2' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-style-dynamic-responsive-css'  href='https://uxcandy.co/wp-content/themes/foton/assets/css/style_dynamic_responsive.css?ver=1582324786' type='text/css' media='all' />
<link   rel='stylesheet' id='foton-mikado-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Poppins%3A400%2C500%2C700%7CNunito%3A400%2C500%2C700%7CRubik%3A400%2C500%2C700%7CRoboto%3A400%2C500%2C700&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<!--[if lt IE 9]>
<link   rel='stylesheet' id='vc_lte_ie9-css'  href='https://uxcandy.co/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.3' type='text/css' media='screen' />
<![endif]-->
<script>if (document.location.protocol != "https:") {document.location = document.URL.replace(/^http:/i, "https:");}</script><script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","download_extensions":"doc,pdf,ppt,zip,xls,docx,pptx,xlsx","inbound_paths":"[{\"path\":\"\\\/go\\\/\",\"label\":\"affiliate\"},{\"path\":\"\\\/recommend\\\/\",\"label\":\"affiliate\"}]","home_url":"https:\/\/uxcandy.co","hash_tracking":"false"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=7.10.4'></script>
<script    type='text/javascript' src='https://uxcandy.co/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script    type='text/javascript' src='https://uxcandy.co/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var jquery_blockui_params = {"cart_url":"https:\/\/uxcandy.co\/checkout\/","i18n_view_cart":"Checkout"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"Checkout","cart_url":"https:\/\/uxcandy.co\/checkout\/","is_cart":"","cart_redirect_after_add":""};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.9.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.0.3'></script>
<link rel='https://api.w.org/' href='https://uxcandy.co/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://uxcandy.co/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://uxcandy.co/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.2" />
<meta name="generator" content="WooCommerce 3.9.2" />
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W9DLC4F');</script>
<!-- End Google Tag Manager -->

<script>
window['_fs_debug'] = false;
window['_fs_host'] = 'fullstory.com';
window['_fs_org'] = 'NS2GA';
window['_fs_namespace'] = 'FS';
(function(m,n,e,t,l,o,g,y){
    if (e in m) {if(m.console && m.console.log) { m.console.log('FullStory namespace conflict. Please set window["_fs_namespace"].');} return;}
    g=m[e]=function(a,b,s){g.q?g.q.push([a,b,s]):g._api(a,b,s);};g.q=[];
    o=n.createElement(t);o.async=1;o.crossOrigin='anonymous';o.src='https://'+_fs_host+'/s/fs.js';
    y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);
    g.identify=function(i,v,s){g(l,{uid:i},s);if(v)g(l,v,s)};g.setUserVars=function(v,s){g(l,v,s)};g.event=function(i,v,s){g('event',{n:i,p:v},s)};
    g.shutdown=function(){g("rec",!1)};g.restart=function(){g("rec",!0)};
    g.log = function(a,b) { g("log", [a,b]) };
    g.consent=function(a){g("consent",!arguments.length||a)};
    g.identifyAccount=function(i,v){o='account';v=v||{};v.acctId=i;g(o,v)};
    g.clearUserCookie=function(){};
})(window,document,window['_fs_namespace'],'script','user');
</script>

<script>
window['_fs_debug'] = false;
window['_fs_host'] = 'fullstory.com';
window['_fs_org'] = 'NS2GA';
window['_fs_namespace'] = 'FS';
(function(m,n,e,t,l,o,g,y){
    if (e in m) {if(m.console && m.console.log) { m.console.log('FullStory namespace conflict. Please set window["_fs_namespace"].');} return;}
    g=m[e]=function(a,b,s){g.q?g.q.push([a,b,s]):g._api(a,b,s);};g.q=[];
    o=n.createElement(t);o.async=1;o.crossOrigin='anonymous';o.src='https://'+_fs_host+'/s/fs.js';
    y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);
    g.identify=function(i,v,s){g(l,{uid:i},s);if(v)g(l,v,s)};g.setUserVars=function(v,s){g(l,v,s)};g.event=function(i,v,s){g('event',{n:i,p:v},s)};
    g.shutdown=function(){g("rec",!1)};g.restart=function(){g("rec",!0)};
    g.log = function(a,b) { g("log", [a,b]) };
    g.consent=function(a){g("consent",!arguments.length||a)};
    g.identifyAccount=function(i,v){o='account';v=v||{};v.acctId=i;g(o,v)};
    g.clearUserCookie=function(){};
})(window,document,window['_fs_namespace'],'script','user');
</script>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="icon" href="https://uxcandy.co/wp-content/uploads/2019/04/Logo_icon.png" sizes="32x32" />
<link rel="icon" href="https://uxcandy.co/wp-content/uploads/2019/04/Logo_icon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://uxcandy.co/wp-content/uploads/2019/04/Logo_icon.png" />
<meta name="msapplication-TileImage" content="https://uxcandy.co/wp-content/uploads/2019/04/Logo_icon.png" />
		<style type="text/css" id="wp-custom-css">
			.elementor-widget-button .elementor-button {
    background: #0C66FF;
    border: none;
    color: #fff;
    display: inline-block;
    font-weight: 500;
    transition: all .2s ease-in-out;
    border-radius: 4px;
    font-size: 16px;
    line-height: 20px;
}
.elementor-widget-button .elementor-button:hover {
	box-shadow: 0px 0px 15px -4px rgb(13, 101, 251);
}

.elementor-element.elementor-button-warning .elementor-button {
    background-color: rgba(255, 143, 0, 0.15);
    color: #ff8f00;
}
.elementor-element.elementor-button-warning .elementor-button:hover {
    box-shadow: 0px 0px 15px -4px rgb(200, 207, 220);
}
.elementor-widget-button .elementor-button:not(.elementor-size-lg):not(.elementor-size-sm) {
    padding: 13px 35px;
}

.elementor-button.elementor-size-sm {
    font-size: 15px;
    line-height: 20px;
    padding: 10px 20px;
}

.mkdf-dark-header .mkdf-page-header>div:not(.mkdf-sticky-header):not(.fixed) .mkdf-main-menu>ul>li>a,
.mkdf-dark-header .mkdf-page-header>div:not(.mkdf-sticky-header):not(.fixed) .mkdf-search-opener,
.mkdf-dark-header .mkdf-top-bar .mkdf-search-opener,
.mkdf-dark-header .mkdf-page-header>div:not(.mkdf-sticky-header):not(.fixed) .mkdf-shopping-cart-holder .mkdf-header-cart,
.mkdf-dark-header .mkdf-page-header>div:not(.mkdf-sticky-header):not(.fixed) .mkdf-icon-widget-holder {
    color: #616161 !important;
}

.elementor-element-0cebacd .elementor-row {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
}

.elementor-element-0cebacd .elementor-row .elementor-column {
    width: 100%;
}

.elementor-element-0cebacd .elementor-row .elementor-column .elementor-widget-wrap {
    display: flex;
    flex-direction: row;
    margin-top: 20px
}

.elementor-element-0cebacd .elementor-row .elementor-column .elementor-widget-wrap .elementor-widget-button {
    display: inline-block;
    width: auto;
    margin-right: 15px;
}

.elementor-9346 .elementor-element.elementor-element-1ac9f2e.elementor-widget-heading .elementor-heading-title {
    max-width: 600px;
}

.elementor-element-0cebacd .elementor-row .elementor-column .elementor-widget-wrap .elementor-widget-button:last-child {
    margin-right: 0;
}

.page-template-blog-standard .mkdf-content {
    margin-top: -120px !important;
}

.mkdf-page-header .mkdf-fixed-wrapper.fixed,
.mkdf-sticky-header.header-appear {
    box-shadow: 0px 0px 10px -1px rgba(74, 136, 173, 0.09);
}

.mkdf-drop-down .second .inner ul {
    border-radius: 4px;
}

.mkdf-drop-down .second {
    box-shadow: 0 10px 55px 5px rgba(0, 0, 0, 0.15);
}

.mkdf-logo-wrapper a img {
    height: auto;
    width: auto;
    margin-top: 2px;
    max-width: 125px;
}

.mkdf-mobile-header .mkdf-mobile-logo-wrapper img {
    display: block;
    height: auto;
    width: auto;
    max-width: 100px;
}

.mkdf-price-table .mkdf-pt-inner ul li.mkdf-pt-content-holder {
    padding: 74px 15px 0 220px;
}

.mkdf-price-table .mkdf-pt-inner ul li.mkdf-pt-prices {
    padding: 51px 35px 0;
    max-width: 225px;
}

.mkdf-woo-single-page .woocommerce-tabs .entry-content {
    padding-top: 45px;
    width: 100% !important;
}

.mkdf-woo-single-page .mkdf-single-product-summary .product_meta,
.mkdf-woo-single-page .mkdf-single-product-summary .mkdf-single-product-meta-title,
.mkdf-woo-single-page .related.products {
    display: none;
}

.mkdf-portfolio-list-holder.mkdf-pl-has-shadow article .mkdf-pli-image {
    box-shadow: 0px 0px 15px -6px rgba(48, 88, 125, 0.35);
}

.mkdf-grid-list .mkdf-item-space:hover .mkdf-pli-image {
    box-shadow: 0px 0px 20px -6px rgba(48, 88, 125, 0.75);
    transition: 0.3s ease-in-out box-shadow;
}

.mkdf-portfolio-list-holder.mkdf-pl-standard-shader article:hover .mkdf-pli-image:after {
    opacity: 0;
}

.elementor-divider-separator {
    border-color: #edf1f3;
}

.mkdf-page-footer .mkdf-footer-top-holder .mkdf-footer-top-inner.mkdf-grid {
    padding: 40px 0;
}

#wpforms-form-8498 {
    justify-content: center;
    display: flex;
}

#wpforms-form-8498 .newsletter-email-field {
    margin-right: 10px;
}

#wpforms-form-8498 .wpforms-field-container {
    min-width: 300px;
}

#wpforms-form-8498 .newsletter-email-field input {
    width: 100%;
    min-width: 100%;
    border: none;
    background: rgb(255, 255, 255);
    font-size: 14px;
    padding: 15px 25px;
    height: auto;
    border-radius: 4px;
    color: rgba(89, 72, 141, 0.41);
    height: 45px;
}

#wpforms-form-8498 button[type=submit] {
    background: #0444b1;
    border: none;
    color: #fff;
    display: inline-block;
    padding: 13px 35px;
    font-weight: 500;
    transition: all .2s ease-in-out;
    border-radius: 4px;
    font-size: 16px;
    line-height: 20px;
}

.elementor-element-78716c7 {
    display: flex;
    align-items: center;
}

.elementor-element-78716c7 div.wpforms-container-full {
    margin-bottom: 0px;
}

.elementor-element-f83a5e8 .elementor-heading-title {
    max-width: 400px;
}

#wpforms-confirmation-8498 {
    color: #ffffff;
    font-weight: 500;
    margin: 0;
    font-size: 22px;
    background: none;
    border: none;
    padding: 15px 15px;
    text-align: center;
}

#wpforms-confirmation-8498 p {
    font-size: inherit;
}

#wpforms-8498-field_1-error {
    color: #fff;
    font-size: 13px;
    font-weight: 500;
    float: none;
    position: absolute;
}

/* -- Woocommerce -- */
form.checkout.woocommerce-checkout {
    display: flex;
    max-width: 1000px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 100px;
}

#customer_details .col-1 {
    width: 80%;
}

.woocommerce-additional-fields,
h3#order_review_heading {
    display: none;
}

.woocommerce-checkout .mkdf-container-inner.clearfix {
    padding-top: 30px !important;
}

.woocommerce-checkout.woocommerce-page .mkdf-container-inner {
    margin-top: 100px;
}

.woocommerce-notices-wrapper {
    position: relative;
    top: 100px;
    max-width: 900px;
    margin-left: auto;
    margin-right: auto;
}

.mkdf-woocommerce-page .woocommerce-message {
    font-family: inherit;
    font-weight: 400;
    border: none;
    background: rgba(13, 101, 251, 0.12941176470588237);
    color: #0d65fb;
    padding: 10px 35px;
    border-radius: 6px;
}

.woocommerce-message a {
    font-weight: 500;
}

.woocommerce-cart .woocommerce {
    display: flex;
}

.woocommerce-cart .woocommerce .woocommerce-cart-form {
    width: 100%;
    max-width: 70%;
}

.woocommerce-cart .woocommerce .woocommerce-cart-form {
    width: 100%;
    max-width: 70%;
}

.woocommerce-cart .woocommerce .cart-collaterals {
    width: 100%;
    max-width: 30%;
    padding-left: 100px;
}

.single-post .mkdf-title-inner{
	display:none;
}

.mkdf-blog-single.mkdf-blog-single-standard {
	padding-top:10px
}

form.checkout.woocommerce-checkout {
    flex-wrap: wrap;
}

form.checkout.woocommerce-checkout #customer_details {
    width: 70%;
}

form.checkout.woocommerce-checkout #order_review {
    width: 30%;
}
		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><!-- WooCommerce Google Analytics Integration -->
		<script type='text/javascript'>
			var gaProperty = 'UA-133737599-1';
			var disableStr = 'ga-disable-' + gaProperty;
			if ( document.cookie.indexOf( disableStr + '=true' ) > -1 ) {
				window[disableStr] = true;
			}
			function gaOptout() {
				document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
				window[disableStr] = true;
			}
		</script>
		<script type='text/javascript'>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script', '//www.google-analytics.com/analytics.js','ga');ga( 'create', 'UA-133737599-1', 'auto' );ga( 'require', 'displayfeatures' );ga( 'require', 'linkid' );ga( 'set', 'anonymizeIp', true );ga( 'send', 'event', 'Error', '404 Not Found', 'page: ' + document.location.pathname + document.location.search + ' referrer: ' + document.referrer );
		ga( 'set', 'dimension1', 'no' );
ga( 'require', 'ec' );</script>
		<!-- /WooCommerce Google Analytics Integration -->
<script type="text/javascript">
    window.heap=window.heap||[],heap.load=function(e,t){window.heap.appid=e,window.heap.config=t=t||{};var r=t.forceSSL||"https:"===document.location.protocol,a=document.createElement("script");a.type="text/javascript",a.async=!0,a.src=(r?"https:":"http:")+"//cdn.heapanalytics.com/js/heap-"+e+".js";var n=document.getElementsByTagName("script")[0];n.parentNode.insertBefore(a,n);for(var o=function(e){return function(){heap.push([e].concat(Array.prototype.slice.call(arguments,0)))}},p=["addEventProperties","addUserProperties","clearEventProperties","identify","resetIdentity","removeEventProperty","setEventProperties","track","unsetEventProperty"],c=0;c<p.length;c++)heap[p[c]]=o(p[c])};
      heap.load("3708185501");
</script>
</head>
<body data-rsssl=1 class="error404 theme-foton foton-core-1.1.1 woocommerce-no-js foton-ver-1.2 mkdf-smooth-scroll mkdf-grid-1300 mkdf-empty-google-api mkdf-wide-dropdown-menu-in-grid mkdf-dark-header mkdf-sticky-header-on-scroll-down-up mkdf-dropdown-default mkdf-header-standard mkdf-menu-area-shadow-disable mkdf-menu-area-in-grid-shadow-disable mkdf-menu-area-border-disable mkdf-menu-area-in-grid-border-disable mkdf-logo-area-border-disable mkdf-logo-area-in-grid-border-disable mkdf-header-vertical-shadow-disable mkdf-header-vertical-border-disable mkdf-woocommerce-columns-3 mkdf-woo-normal-space mkdf-woo-pl-info-below-image mkdf-woo-single-thumb-below-image mkdf-woo-single-has-pretty-photo mkdf-default-mobile-header mkdf-sticky-up-mobile-header mkdf-search-covers-header wpb-js-composer js-comp-ver-6.0.3 vc_responsive elementor-default" itemscope itemtype="http://schema.org/WebPage">
	
    <div class="mkdf-wrapper">
        <div class="mkdf-wrapper-inner">
            
<header class="mkdf-page-header">
		
				
	<div class="mkdf-menu-area mkdf-menu-right">
				
						
			<div class="mkdf-vertical-align-containers">
				<div class="mkdf-position-left"><!--
				 --><div class="mkdf-position-left-inner">
						
	
	<div class="mkdf-logo-wrapper">
		<a itemprop="url" href="https://uxcandy.co/" style="height: 30px;">
			<img itemprop="image" class="mkdf-normal-logo" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="logo"/>
			<img itemprop="image" class="mkdf-dark-logo" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="dark logo"/>			<img itemprop="image" class="mkdf-light-logo" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="light logo"/>		</a>
	</div>

											</div>
				</div>
								<div class="mkdf-position-right"><!--
				 --><div class="mkdf-position-right-inner">
														
	<nav class="mkdf-main-menu mkdf-drop-down mkdf-default-nav">
		<ul id="menu-main-menu" class="clearfix"><li id="nav-menu-item-10429" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="https://uxcandy.co/" class=""><span class="item_outer"><span class="item_text">Home</span></span></a></li>
<li id="nav-menu-item-8428" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="https://uxcandy.co/blog/" class=""><span class="item_outer"><span class="item_text">Blog</span></span></a></li>
<li id="nav-menu-item-13484" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children  has_sub narrow"><a href="https://uxcandy.co/" class=""><span class="item_outer"><span class="item_text">Products</span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-10428" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://uxcandy.co/product/label-pro-admin-template/" class=""><span class="item_outer"><span class="item_text">Label Admin Dashboard</span></span></a></li>
	<li id="nav-menu-item-10569" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://uxcandy.co/product/ripple-admin-template-pro/" class=""><span class="item_outer"><span class="item_text">RippleUI Dashboard</span></span></a></li>
</ul></div></div>
</li>
</ul>	</nav>

												
            <a   class="mkdf-search-opener mkdf-icon-has-hover mkdf-search-opener-svg-path" href="javascript:void(0)">
            <span class="mkdf-search-opener-wrapper">
	            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 21">
<defs>
    <style>
      .search-1 {
        fill: #58468c;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path class="search-1" d="M21.5,19.3h0l-4.669-4.667a9.007,9.007,0,1,0-1.389,1.388l4.67,4.669a0.991,0.991,0,0,0,.694.29,0.985,0.985,0,0,0,.98-0.984A0.978,0.978,0,0,0,21.5,19.3ZM16.838,9A7.033,7.033,0,1,1,9.8,1.967,7.043,7.043,0,0,1,16.838,9Z"/>
</svg>
                            </span>
            </a>
        
            <a class="mkdf-icon-widget-holder"  href="https://uxcandy.co/my-account/edit-account/" target="_self" style="margin: 4px 10px 0px 0px">
                <span class="mkdf-icon-element dripicons-user" style="font-size: 20px"></span>                            </a>
                        <div class="mkdf-shopping-cart-holder" style="margin: ">
                <div class="mkdf-shopping-cart-inner">
                    <a itemprop="url" class="mkdf-header-cart mkdf-header-cart-svg-path" href="https://uxcandy.co/cart/">
                        <span class="mkdf-cart-icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="21" viewBox="0 0 22 21">
                           
<defs>
    <style>
      .cls-1 {
        fill: #58468c;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path id="Store" class="cls-1" d="M6.1,2.095v0h0Zm15.49,4.087c-0.014-.017-0.027-0.028-0.034-0.036L21.4,6.03h0l-0.2-.108a0.194,0.194,0,0,0-.1-0.032L6.134,3.976V2.348L6.122,2.212,6.116,2.185l-0.3-.53L5.8,1.638l-0.04-.031C5.749,1.6,5.74,1.6,5.73,1.591l-3.5-1.4A1,1,0,0,0,.958.688,0.891,0.891,0,0,0,.943,1.4a0.945,0.945,0,0,0,.543.525l2.68,1.047V14.943a2.688,2.688,0,0,0,1.968,2.528,2.46,2.46,0,0,0-.168.89,2.728,2.728,0,0,0,2.813,2.628,2.728,2.728,0,0,0,2.813-2.628,2.468,2.468,0,0,0-.119-0.761h4.234a2.471,2.471,0,0,0-.12.761,2.819,2.819,0,0,0,5.626,0,2.729,2.729,0,0,0-2.813-2.63H7.011a0.839,0.839,0,0,1-.881-0.788v-0.95a3.086,3.086,0,0,0,.881.129H18.985a2.759,2.759,0,0,0,2.844-2.658V6.75l0-.123v0l0.006-.03ZM19.866,7.611v3.846a0.842,0.842,0,0,1-.881.794H7.011a0.84,0.84,0,0,1-.881-0.788v-5.6ZM8.784,19.116a0.81,0.81,0,0,1-.849-0.761A0.819,0.819,0,0,1,8.784,17.6,0.764,0.764,0,1,1,8.784,19.116Zm9.62,0a0.809,0.809,0,0,1-.849-0.761A0.819,0.819,0,0,1,18.4,17.6,0.764,0.764,0,1,1,18.4,19.116Z"/>
</svg>
</span>
                        <span class="mkdf-cart-number">0</span>
                    </a>
                    <div class="mkdf-shopping-cart-dropdown">
                        <ul>
                                                            <li class="mkdf-empty-cart">No products in the cart.</li>
                                                    </ul>
                    </div>
                </div>
            </div>
            					</div>
				</div>
			</div>
			
			</div>
			
		
	
<div class="mkdf-sticky-header">
        <div class="mkdf-sticky-holder mkdf-menu-right">
                <div class="mkdf-grid">
                        <div class="mkdf-vertical-align-containers">
                <div class="mkdf-position-left"><!--
                 --><div class="mkdf-position-left-inner">
                        
	
	<div class="mkdf-logo-wrapper">
		<a itemprop="url" href="https://uxcandy.co/" style="height: 30px;">
			<img itemprop="image" class="mkdf-normal-logo" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="logo"/>
			<img itemprop="image" class="mkdf-dark-logo" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="dark logo"/>			<img itemprop="image" class="mkdf-light-logo" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="light logo"/>		</a>
	</div>

                                            </div>
                </div>
                                <div class="mkdf-position-right"><!--
                 --><div class="mkdf-position-right-inner">
                                                    
<nav class="mkdf-main-menu mkdf-drop-down mkdf-sticky-nav">
    <ul id="menu-main-menu-1" class="clearfix"><li id="sticky-nav-menu-item-10429" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="https://uxcandy.co/" class=""><span class="item_outer"><span class="item_text">Home</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-8428" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="https://uxcandy.co/blog/" class=""><span class="item_outer"><span class="item_text">Blog</span><span class="plus"></span></span></a></li>
<li id="sticky-nav-menu-item-13484" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children  has_sub narrow"><a href="https://uxcandy.co/" class=""><span class="item_outer"><span class="item_text">Products</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="sticky-nav-menu-item-10428" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://uxcandy.co/product/label-pro-admin-template/" class=""><span class="item_outer"><span class="item_text">Label Admin Dashboard</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-10569" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://uxcandy.co/product/ripple-admin-template-pro/" class=""><span class="item_outer"><span class="item_text">RippleUI Dashboard</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
</ul></nav>

                                                
            <a   class="mkdf-search-opener mkdf-icon-has-hover mkdf-search-opener-svg-path" href="javascript:void(0)">
            <span class="mkdf-search-opener-wrapper">
	            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 21">
<defs>
    <style>
      .search-1 {
        fill: #58468c;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path class="search-1" d="M21.5,19.3h0l-4.669-4.667a9.007,9.007,0,1,0-1.389,1.388l4.67,4.669a0.991,0.991,0,0,0,.694.29,0.985,0.985,0,0,0,.98-0.984A0.978,0.978,0,0,0,21.5,19.3ZM16.838,9A7.033,7.033,0,1,1,9.8,1.967,7.043,7.043,0,0,1,16.838,9Z"/>
</svg>
                            </span>
            </a>
                    <div class="mkdf-shopping-cart-holder" style="margin: ">
                <div class="mkdf-shopping-cart-inner">
                    <a itemprop="url" class="mkdf-header-cart mkdf-header-cart-svg-path" href="https://uxcandy.co/cart/">
                        <span class="mkdf-cart-icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="21" viewBox="0 0 22 21">
                           
<defs>
    <style>
      .cls-1 {
        fill: #58468c;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path id="Store" class="cls-1" d="M6.1,2.095v0h0Zm15.49,4.087c-0.014-.017-0.027-0.028-0.034-0.036L21.4,6.03h0l-0.2-.108a0.194,0.194,0,0,0-.1-0.032L6.134,3.976V2.348L6.122,2.212,6.116,2.185l-0.3-.53L5.8,1.638l-0.04-.031C5.749,1.6,5.74,1.6,5.73,1.591l-3.5-1.4A1,1,0,0,0,.958.688,0.891,0.891,0,0,0,.943,1.4a0.945,0.945,0,0,0,.543.525l2.68,1.047V14.943a2.688,2.688,0,0,0,1.968,2.528,2.46,2.46,0,0,0-.168.89,2.728,2.728,0,0,0,2.813,2.628,2.728,2.728,0,0,0,2.813-2.628,2.468,2.468,0,0,0-.119-0.761h4.234a2.471,2.471,0,0,0-.12.761,2.819,2.819,0,0,0,5.626,0,2.729,2.729,0,0,0-2.813-2.63H7.011a0.839,0.839,0,0,1-.881-0.788v-0.95a3.086,3.086,0,0,0,.881.129H18.985a2.759,2.759,0,0,0,2.844-2.658V6.75l0-.123v0l0.006-.03ZM19.866,7.611v3.846a0.842,0.842,0,0,1-.881.794H7.011a0.84,0.84,0,0,1-.881-0.788v-5.6ZM8.784,19.116a0.81,0.81,0,0,1-.849-0.761A0.819,0.819,0,0,1,8.784,17.6,0.764,0.764,0,1,1,8.784,19.116Zm9.62,0a0.809,0.809,0,0,1-.849-0.761A0.819,0.819,0,0,1,18.4,17.6,0.764,0.764,0,1,1,18.4,19.116Z"/>
</svg>
</span>
                        <span class="mkdf-cart-number">0</span>
                    </a>
                    <div class="mkdf-shopping-cart-dropdown">
                        <ul>
                                                            <li class="mkdf-empty-cart">No products in the cart.</li>
                                                    </ul>
                    </div>
                </div>
            </div>
                                </div>
                </div>
            </div>
                    </div>
            </div>
	</div>

	
	<form action="https://uxcandy.co/" class="mkdf-search-cover" method="get">
				<div class="mkdf-form-holder-outer">
				<div class="mkdf-form-holder">
					<div class="mkdf-form-holder-inner">
						<span aria-hidden="true" class="mkdf-icon-font-elegant icon_search" style="float:left; font-size: 20px;"></span>
						<input type="text" placeholder="Type your search..." name="s" class="mkdf_search_field" autocomplete="off" />
						<a class="mkdf-search-close mkdf-search-close-svg-path" href="#">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40" x="0px" y="0px"
	 viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#7AA0FF;}
</style>
<g>
	<path class="st0" d="M35,0H5C2.2,0,0,2.2,0,5v30c0,2.8,2.2,5,5,5h30c2.8,0,5-2.2,5-5V5C40,2.2,37.8,0,35,0z M27.1,25.7l-1.4,1.4
		L20,21.4l-5.7,5.7l-1.4-1.4l5.7-5.7l-5.7-5.7l1.4-1.4l5.7,5.7l5.7-5.7l1.4,1.4L21.4,20L27.1,25.7z"/>
</g>
</svg>
						</a>
					</div>
				</div>
			</div>
	</form></header>


<header class="mkdf-mobile-header">
		
	<div class="mkdf-mobile-header-inner">
		<div class="mkdf-mobile-header-holder">
			<div class="mkdf-grid">
				<div class="mkdf-vertical-align-containers">
					<div class="mkdf-vertical-align-containers">
													<div class="mkdf-mobile-menu-opener mkdf-mobile-menu-opener-icon-pack">
								<a href="javascript:void(0)">
									<span class="mkdf-mobile-menu-icon">
										<i class="mkdf-icon-font-awesome fa fa-bars "></i>									</span>
																	</a>
							</div>
												<div class="mkdf-position-center"><!--
						 --><div class="mkdf-position-center-inner">
								

<div class="mkdf-mobile-logo-wrapper">
    <a itemprop="url" href="https://uxcandy.co/" style="height: 30px">
        <img itemprop="image" src="https://uxcandy.co/wp-content/uploads/2019/04/logo_dark.png"  alt="Mobile Logo"/>
    </a>
</div>

							</div>
						</div>
						<div class="mkdf-position-right"><!--
						 --><div class="mkdf-position-right-inner">
								            <div class="mkdf-shopping-cart-holder" style="margin: ">
                <div class="mkdf-shopping-cart-inner">
                    <a itemprop="url" class="mkdf-header-cart mkdf-header-cart-svg-path" href="https://uxcandy.co/cart/">
                        <span class="mkdf-cart-icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="21" viewBox="0 0 22 21">
                           
<defs>
    <style>
      .cls-1 {
        fill: #58468c;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path id="Store" class="cls-1" d="M6.1,2.095v0h0Zm15.49,4.087c-0.014-.017-0.027-0.028-0.034-0.036L21.4,6.03h0l-0.2-.108a0.194,0.194,0,0,0-.1-0.032L6.134,3.976V2.348L6.122,2.212,6.116,2.185l-0.3-.53L5.8,1.638l-0.04-.031C5.749,1.6,5.74,1.6,5.73,1.591l-3.5-1.4A1,1,0,0,0,.958.688,0.891,0.891,0,0,0,.943,1.4a0.945,0.945,0,0,0,.543.525l2.68,1.047V14.943a2.688,2.688,0,0,0,1.968,2.528,2.46,2.46,0,0,0-.168.89,2.728,2.728,0,0,0,2.813,2.628,2.728,2.728,0,0,0,2.813-2.628,2.468,2.468,0,0,0-.119-0.761h4.234a2.471,2.471,0,0,0-.12.761,2.819,2.819,0,0,0,5.626,0,2.729,2.729,0,0,0-2.813-2.63H7.011a0.839,0.839,0,0,1-.881-0.788v-0.95a3.086,3.086,0,0,0,.881.129H18.985a2.759,2.759,0,0,0,2.844-2.658V6.75l0-.123v0l0.006-.03ZM19.866,7.611v3.846a0.842,0.842,0,0,1-.881.794H7.011a0.84,0.84,0,0,1-.881-0.788v-5.6ZM8.784,19.116a0.81,0.81,0,0,1-.849-0.761A0.819,0.819,0,0,1,8.784,17.6,0.764,0.764,0,1,1,8.784,19.116Zm9.62,0a0.809,0.809,0,0,1-.849-0.761A0.819,0.819,0,0,1,18.4,17.6,0.764,0.764,0,1,1,18.4,19.116Z"/>
</svg>
</span>
                        <span class="mkdf-cart-number">0</span>
                    </a>
                    <div class="mkdf-shopping-cart-dropdown">
                        <ul>
                                                            <li class="mkdf-empty-cart">No products in the cart.</li>
                                                    </ul>
                    </div>
                </div>
            </div>
            							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<nav class="mkdf-mobile-nav" role="navigation" aria-label="Mobile Menu">
    <div class="mkdf-grid">
        <ul id="menu-main-menu-2" class=""><li id="mobile-menu-item-10429" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://uxcandy.co/" class=""><span>Home</span></a></li>
<li id="mobile-menu-item-8428" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://uxcandy.co/blog/" class=""><span>Blog</span></a></li>
<li id="mobile-menu-item-13484" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children  has_sub"><a href="https://uxcandy.co/" class=""><span>Products</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow arrow_carrot-right"></i><i class="arrow_carrot-down"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-10428" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://uxcandy.co/product/label-pro-admin-template/" class=""><span>Label Admin Dashboard</span></a></li>
	<li id="mobile-menu-item-10569" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://uxcandy.co/product/ripple-admin-template-pro/" class=""><span>RippleUI Dashboard</span></a></li>
</ul>
</li>
</ul>    </div>
</nav>
	</div>
	
	<form action="https://uxcandy.co/" class="mkdf-search-cover" method="get">
				<div class="mkdf-form-holder-outer">
				<div class="mkdf-form-holder">
					<div class="mkdf-form-holder-inner">
						<span aria-hidden="true" class="mkdf-icon-font-elegant icon_search" style="float:left; font-size: 20px;"></span>
						<input type="text" placeholder="Type your search..." name="s" class="mkdf_search_field" autocomplete="off" />
						<a class="mkdf-search-close mkdf-search-close-svg-path" href="#">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40" x="0px" y="0px"
	 viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#7AA0FF;}
</style>
<g>
	<path class="st0" d="M35,0H5C2.2,0,0,2.2,0,5v30c0,2.8,2.2,5,5,5h30c2.8,0,5-2.2,5-5V5C40,2.2,37.8,0,35,0z M27.1,25.7l-1.4,1.4
		L20,21.4l-5.7,5.7l-1.4-1.4l5.7-5.7l-5.7-5.7l1.4-1.4l5.7,5.7l5.7-5.7l1.4,1.4L21.4,20L27.1,25.7z"/>
</g>
</svg>
						</a>
					</div>
				</div>
			</div>
	</form></header>

			<a id='mkdf-back-to-top' href='#'>
				<span class="mkdf-btt-wrapper">
					<svg class="mkdf-btt-svg-top" x="0px" y="0px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
						<g class="mkdf-arrow">
							<path d="M20,30L20,30c-0.6,0-1-0.4-1-1V13c0-0.6,0.4-1,1-1h0c0.6,0,1,0.4,1,1v16C21,29.6,20.6,30,20,30z"/>
							<path d="M26.4,16.4l-5.7-5.7c-0.4-0.4-1-0.4-1.4,0l-5.7,5.7c-0.4,0.4-0.4,1,0,1.4c0.4,0.4,1,0.4,1.4,0l4.9-4.9l4.9,4.9   c0.4,0.4,1,0.4,1.4,0C26.8,17.4,26.8,16.8,26.4,16.4z"/>
						</g>
					</svg>
				</span>
			</a>
			        
            <div class="mkdf-content" style="margin-top: -65px">
                <div class="mkdf-content-inner"><div class="mkdf-page-not-found">
	
	<h2 class="mkdf-404-title">
		Error page 404	</h2>

	<h2 class="mkdf-404-subtitle">
		 	</h2>

	<p class="mkdf-404-text">
		Oops! The page you are looking for does not exist. It might have been moved or deleted.	</p>

	<a itemprop="url" href="https://uxcandy.co/" target="_self"  class="mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-icon"  >    <span class="mkdf-btn-text">Back to home</span>    <span aria-hidden="true" class="mkdf-icon-font-elegant arrow_carrot-right " ></span></a></div>
</div>
</div>
</div>
</div>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W9DLC4F"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript'>
/* <![CDATA[ */
var countVars = {"disqusShortname":"uxcandy-2"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/disqus-comment-system/public/js/comment_count.js?ver=3.0.17'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var js_cookie_params = {"cart_url":"https:\/\/uxcandy.co\/checkout\/","i18n_view_cart":"Checkout"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_url":"https:\/\/uxcandy.co\/checkout\/","i18n_view_cart":"Checkout"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.9.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_366b3e684240cd8c3c4eb97279b76770","fragment_name":"wc_fragments_366b3e684240cd8c3c4eb97279b76770","request_timeout":"5000","cart_url":"https:\/\/uxcandy.co\/checkout\/","i18n_view_cart":"Checkout"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.9.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4'></script>
<script   type='text/javascript'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.13-9993131'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.appear.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/modernizr.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-includes/js/hoverIntent.min.js?ver=1.8.1'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.plugin.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/owl.carousel.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.waypoints.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/fluidvids.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/parallax.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.parallax-scroll.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.waitforimages.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.prettyPhoto.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.easing.1.3.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.0.3'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/packery-mode.pkgd.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.0'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/jquery.geocomplete.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/foton-core/shortcodes/countdown/assets/js/plugins/jquery.countdown.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/foton-core/shortcodes/counter/assets/js/plugins/counter.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/foton-core/shortcodes/counter/assets/js/plugins/absoluteCounter.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/foton-core/shortcodes/custom-font/assets/js/plugins/typed.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/foton-core/shortcodes/pie-chart/assets/js/plugins/easypiechart.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/foton-core/shortcodes/vertical-split-slider/assets/js/plugins/jquery.multiscroll.min.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var select2_params = {"cart_url":"https:\/\/uxcandy.co\/checkout\/","i18n_view_cart":"Checkout"};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/TweenLite.min.js?ver=5.4.2'></script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules/plugins/smoothPageScroll.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mkdfGlobalVars = {"vars":{"mkdfAddForAdminBar":0,"mkdfElementAppearAmount":-100,"mkdfAjaxUrl":"https:\/\/uxcandy.co\/wp-admin\/admin-ajax.php","mkdfStickyHeaderHeight":0,"mkdfStickyHeaderTransparencyHeight":65,"mkdfTopBarHeight":0,"mkdfLogoAreaHeight":0,"mkdfMenuAreaHeight":65,"mkdfMobileHeaderHeight":70}};
var mkdfPerPageVars = {"vars":{"mkdfMobileHeaderHeight":70,"mkdfStickyScrollAmount":0,"mkdfHeaderTransparencyHeight":0,"mkdfHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script   type='text/javascript' src='https://uxcandy.co/wp-content/themes/foton/assets/js/modules.min.js?ver=5.4.2'></script>
<script   type='text/javascript'>
(function($){
    $(document).ready(function(){
        if ($('.mkdf-homes-holder').length) {
            $('.mkdf-homes-holder .mkdf-image-with-text-holder').appear(function() {
                $(this).addClass('mkdf-appeared');
            },{accX: 0, accY: mkdfGlobalVars.vars.mkdfElementAppearAmount});
        }
    });
})(jQuery);
</script>
<!-- WooCommerce JavaScript -->
<script type="text/javascript">
jQuery(function($) { 

					$( '.add_to_cart_button:not(.product_type_variable, .product_type_grouped)' ).click( function() {
						ga( 'ec:addProduct', {'id': ($(this).data('product_sku')) ? ($(this).data('product_sku')) : ('#' + $(this).data('product_id')),'quantity': $(this).data('quantity')} );
						ga( 'ec:setAction', 'add' );
						ga( 'send', 'event', 'UX', 'click', 'add to cart' );
					});
				

ga( 'send', 'pageview' ); 
 });
</script>
</body>
</html>
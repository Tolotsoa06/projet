var table;
$(document).ready(function() {
    table = $("#horizontal-scroll-table").DataTable({
        stateSave: !0,
        scrollY: "50vh",
        scrollX: !0,
        scrollCollapse: !0,
        "language": {
            "url": 'french.json'
        },
        "ajax": {
            "url": "action/evenement.php?liste=1",
            "dataSrc": "data"
        },
        "columns": [{
                data: 'image'
            }, {
                data: 'titre'
            },
            {
                data: 'description'
            },
            {
                data: 'debut'
            }, {
                data: 'fin'
            },
            {
                data: 'action'
            }
        ]
    })
});

$("#FormEvenement").on('submit', function() {
    var form = new FormData(this);
    var titre = $("#titre").val();
    var description = $("#description").val();
    var image = $("#image").val();
    var date_debut = $("#date_debut").val();
    var heure_debut = $("#heure_debut").val();
    var date_fin = $("#date_fin").val();
    var heure_fin = $("#heure_fin").val();
    if (titre && description && image && date_debut && heure_debut && date_fin && heure_fin) {
        $.ajax({
            url: 'action/ajout_evenement.php',
            type: 'POST',
            contentType: false,
            data: form,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(data) {
                table.ajax.reload();
                $("#FormEvenement")[0].reset();
                $("#modal_ajout").modal('hide');
            }
        });
    } else {
        $(".dismissible-alert > p").text("Veuillez completez tous les champs pour ajouter l'évènement");
        $(".dismissible-alert").attr('style', '');
    }
    return false;
});

function supprimer(id) {
    if (id) {
        if (confirm('Etes-vous sur de supprimer cet évènement ? ')) {
            $.ajax({
                url: 'action/evenement.php',
                type: 'POST',
                data: {
                    supprimer: 1,
                    id: id
                },
                dataType: 'json',
                success: function(response) {
                    table.ajax.reload();
                }
            });
        }
    }
}
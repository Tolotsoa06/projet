var table;
$(document).ready(function() {
    table = $("#horizontal-scroll-table").DataTable({
        stateSave: !0,
        scrollY: "50vh",
        scrollX: !0,
        scrollCollapse: !0,
        "language": {
            "url": 'french.json'
        },
        "ajax": {
            "url": "action/Administrateur.php?liste=1",
            "dataSrc": "data"
        },
        "columns": [{
                data: 'nom'
            },
            {
                data: 'email'
            },
            {
                data: 'username'
            },
            {
                data: 'avatar'
            },
            {
                data: 'action'
            }
        ]
    })
});

function supprimer(id) {
    if (id) {
        if (window.localStorage.getItem('id') == id) {
            alert('Impossible de supprimer un compte qui est connecté');
        } else if (confirm('Etes-vous sur de supprimer cet administrateur?')) {
            $.ajax({
                url: 'action/Administrateur.php',
                type: "POST",
                data: {
                    id_admin: id,
                    supprimer: 1
                },
                dataType: 'json',
                success: function(response) {
                    table.ajax.reload();
                }
            });
        }
    }
}


$("#FormAdmin").on('submit', function() {
    var form = new FormData(this);
    var nom = $("#nom").val();
    var email = $("#email").val();
    var username = $("#username").val();
    var password = $("#password").val();
    var image = $("#image").val();
    if (nom && email && username && password && image) {
        $.ajax({
            url: 'action/ajout_administrateur.php',
            type: 'POST',
            contentType: false,
            data: form,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(data) {
                table.ajax.reload();
                $("#FormAdmin")[0].reset();
            }
        });
    } else {
        $(".dismissible-alert > p").text("Veuillez completez tous les champs pour ajouter un administrateur");
        $(".dismissible-alert").attr('style', '');
    }
    return false;
});
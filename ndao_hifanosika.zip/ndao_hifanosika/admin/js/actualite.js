var table;
$(document).ready(function() {
    table = $("#horizontal-scroll-table").DataTable({
        stateSave: !0,
        scrollY: "50vh",
        scrollX: !0,
        scrollCollapse: !0,
        "language": {
            "url": 'french.json'
        },
        "ajax": {
            "url": "action/actualite.php?liste=1",
            "dataSrc": "data"
        },
        "columns": [{
                data: 'titre'
            },
            {
                data: 'image'
            },
            {
                data: 'action'
            }
        ]
    })
});

function detail(id) {
    if (id) {
        $.ajax({
            url: 'action/actualite.php',
            type: 'POST',
            data: {
                detail: 1,
                id: id
            },
            dataType: 'json',
            success: function(response) {
                $(".content-viewport").html(afficher_actualite(response));
            }
        });
    }
}

function supprimer(id) {
    if (id) {
        if (confirm('Etes-vous sur de supprimer cette actualité?')) {
            $.ajax({
                url: 'action/actualite.php',
                type: "POST",
                data: {
                    id: id,
                    supprimer: 1
                },
                dataType: 'json',
                success: function(response) {
                    table.ajax.reload();
                }
            });
        }
    }
}

function afficher_actualite(actualite) {
    return "<div class='grid'>" +
        "<p class='grid-header text-center'>Détail de l'actualité</p>" +
        "<div class='grid-body'>" +
        "<div class='item-wrapper'>" +
        "<div class='row'>" +
        "<div class='col-lg-6'>" +
        "<p class='mb-3'><span class='h3'>Titre : </span>" +
        "<b>" + actualite.titre + "</b></p>" +
        "<h4>Image</h4><br>" +
        "<img src='" + actualite.image + "' class='img-xxl'/>" +
        "</div>" +
        "<div class='col-lg-6'>" +
        "<h4>Contenu</h4>" +
        "<p>" + actualite.contenu + "</p>" +
        "</div>" +
        "</div>" +
        "</div>" +
        "</div>" +
        "</div>";
}

$("#FormActualite").on('submit', function() {
    var form = new FormData(this);
    var titre = $("#titre").val();
    var contenue = $("#contenue").val();
    var image = $("#image").val();
    if (titre && contenue && image) {
        $.ajax({
            url: 'action/ajout_actualite.php',
            type: 'POST',
            contentType: false,
            data: form,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(data) {
                table.ajax.reload();
                $("#FormActualite")[0].reset();
            }
        });
    } else {
        $(".dismissible-alert > p").text("Veuillez completez tous les champs pour ajouter l'actualité");
        $(".dismissible-alert").attr('style', '');
    }
    return false;
});
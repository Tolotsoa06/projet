$("#loginForm").on('submit', function() {
    let email = $("#email").val();
    let password = $("#password").val();

    if (email && password) {
        $.ajax({
            url: 'action/login.php',
            type: 'POST',
            data: {
                email: email,
                password: password
            },
            dataType: 'json',
            success: function(response) {
                if (response.nom) {
                    window.localStorage.setItem('id', response.id);
                    window.localStorage.setItem('token', response.token);
                    document.location.href = 'index.php';
                } else {
                    $(".dismissible-alert > p").text(response);
                    $(".dismissible-alert").attr('style', '');
                }
            }
        });
    } else {
        $(".dismissible-alert > p").text("Veuillez completez tous les champs pour vérifier votre identité");
        $(".dismissible-alert").attr('style', '');
    }
    return false;
});
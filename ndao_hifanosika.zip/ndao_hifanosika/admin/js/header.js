var table;
$(document).ready(function() {
    table = $("#horizontal-scroll-table").DataTable({
        stateSave: !0,
        scrollY: "50vh",
        scrollX: !0,
        scrollCollapse: !0,
        "language": {
            "url": 'french.json'
        },
        "ajax": {
            "url": "action/header.php?liste=1",
            "dataSrc": "data"
        },
        "columns": [{
                data: 'titre'
            },
            {
                data: 'texte'
            }, {
                data: 'image'
            },
            {
                data: 'action'
            }
        ]
    })
});

$("#FormHeader").on('submit', function() {
    var form = new FormData(this);
    var titre = $("#titre").val();
    var texte = $("#texte").val();
    var image = $("#image").val();
    if (texte && titre && image) {
        $.ajax({
            url: 'action/ajout_header.php',
            type: 'POST',
            contentType: false,
            data: form,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(data) {
                table.ajax.reload();
                $("#FormHeader")[0].reset();
            }
        });
    } else {
        $(".dismissible-alert > p").text("Veuillez completez tous les champs pour ajouter un element dans votre diaporama");
        $(".dismissible-alert").attr('style', '');
    }
    return false;
});

function supprimer(id) {
    if (id) {
        if (confirm('Etes-vous sur de supprimer cet element ? ')) {
            $.ajax({
                url: 'action/header.php',
                type: 'POST',
                data: {
                    supprimer: 1,
                    id: id
                },
                dataType: 'json',
                success: function(response) {
                    table.ajax.reload();
                }
            });
        }
    }
}
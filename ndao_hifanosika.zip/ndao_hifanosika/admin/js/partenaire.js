var table;
$(document).ready(function() {
    table = $("#horizontal-scroll-table").DataTable({
        stateSave: !0,
        scrollY: "50vh",
        scrollX: !0,
        scrollCollapse: !0,
        "language": {
            "url": 'french.json'
        },
        "ajax": {
            "url": "action/partenaire.php?liste=1",
            "dataSrc": "data"
        },
        "columns": [{
                data: 'nom'
            },
            {
                data: 'site'
            }, {
                data: 'image'
            },
            {
                data: 'action'
            }
        ]
    })
});

$("#FormPartenaire").on('submit', function() {
    var form = new FormData(this);
    var nom = $("#nom").val();
    var site = $("#site").val();
    var image = $("#image").val();
    if (site && nom && image) {
        $.ajax({
            url: 'action/ajout_partenaire.php',
            type: 'POST',
            contentType: false,
            data: form,
            cache: false,
            processData: false,
            dataType: 'json',
            success: function(data) {
                table.ajax.reload();
                $("#FormPartenaire")[0].reset();
            }
        });
    } else {
        $(".dismissible-alert > p").text("Veuillez completez tous les champs pour ajouter votre partenaire");
        $(".dismissible-alert").attr('style', '');
    }
    return false;
});

function supprimer(id) {
    if (id) {
        if (confirm('Etes-vous sur de supprimer ce partenaire ? ')) {
            $.ajax({
                url: 'action/partenaire.php',
                type: 'POST',
                data: {
                    supprimer: 1,
                    id: id
                },
                dataType: 'json',
                success: function(response) {
                    table.ajax.reload();
                }
            });
        }
    }
}
$(document).ready(function() {
    getLogin();
})

function getLogin() {
    let id = window.localStorage.getItem('id') ? window.localStorage.getItem('id') : 0;
    if (id != 0) {
        $.ajax({
            url: 'action/Administrateur.php',
            type: 'POST',
            data: {
                id: id
            },
            dataType: 'json',
            success: function(response) {
                if (window.localStorage.getItem('token') == response.token) {
                    $(".user-name").text(response.nom);
                    $(".profile-img").attr('src', response.avatar);
                } else {
                    window.location.href = 'login.php';
                }
            }
        })
    } else {
        window.location.href = 'login.php';
    }
}

function logOut() {
    window.localStorage.clear();
    window.location.href = 'login.php';
}

$(".logOut").on('click', function() {
    logOut();
})
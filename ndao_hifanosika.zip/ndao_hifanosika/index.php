<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/flaticons/font/flaticon.css">
    <link rel="stylesheet" href="assets/css/sweetalert2.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="assets/img/ndao_hifanosika.png" type="image/x-icon">
</head>

<body>
    <header role="banner">
        <nav class="navbar navbar-expand-md" id="menu">
            <div class="container">
                <a class="navbar-brand" href="index.php"><img src="assets/img/ndao_hifanosika.png" width="55px" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-navicon"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarsExample05">
                    <ul class="navbar-nav ml-auto pl-lg-5 pl-0">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#apropos">A propos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">Evènements</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="news.html">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <section class="home-slider owl-carousel">

    </section>
    <section class="section element-animate">

        <div class="clearfix mb-5 pb-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 text-center heading-wrap">
                        <h2>Nos Actualités</h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="owl-carousel actualite-slider">
        </div>
        <div class="container-fluid clearfix m-0">
            <div class="row">
                <div class="col-md-12 text-right">
                    <a href="actualites.php" class="link-actualite">Voir tous les actualités</a>
                </div>
            </div>
        </div>
    </section>

    <section class="section bg-light element-animate" id="apropos">
        <div class="clearfix pb-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 text-center heading-wrap">
                        <h2>A Propos</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 pl-5 pr-5">
                    <h4 class="text-center">Qui sommes-nous?</h4>
                    <p class="text-justify text-dark">
                        <b>Ndao hifanosika Fianara</b> est un club des jeunes Fianarois, apolitique, citoyenne et qui se veut de faire un réveil collectif de conscience et d'esprit de la population de la province dans le but de pallier aux différents problèmes liés au manque de travail qui y règne. Éveiller l'esprit en y faisant la promotion de la culture entrepreneuriale, l'entrepreneuriat pour qu'on puisse enfin exploiter nos matières grises et nos richesses afin d'y créer des activités, sources de revenus efficaces et durables tout en respectant l'environnement, les us et coutumes. On contribue aussi fortement aux sensibilisations de surtout s'entraider entre fianarois peu importe qui nous sommes. <b>En une phrase, développer la province avec l'entrepreneuriat tout en s'entraidant sans attendre une quelconque aide de l’État, d'où l'origine du nom du club.</b>
                    </p>
                </div>
                <div class="col-md-6">

                </div>
            </div>
        </div>
    </section>

    <section class="section bg-light element-animate">
        <div class="clearfix pb-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 text-center heading-wrap">
                        <h2>ILS NOUS SOUTIENNENTS</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="owl-carousel centernonloop pr-5 pl-5">

        </div>
    </section>

    <section class="section element-animate contact">
        <div class="row">
            <div class="col-md-6">
                <h5>Ndao Hifanosika Fianara</h5>
                <h3>CONTACTS</h3>
            </div>
            <div class="col-md-6">
                <form action="#" method="POST" id="formContact">
                    <div class="form-group">
                        <input type="text" name="nom" id="nom" class="form-control" placeholder="Votre Nom">
                    </div>
                    <div class="form-group">
                        <input type="text" name="email" id="email" class="form-control" placeholder="Votre Email">
                    </div>
                    <div class="form-group">
                        <input type="text" name="sujet" id="sujet" class="form-control" placeholder="Votre Sujet">
                    </div>
                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control" placeholder="Votre message"></textarea>
                    </div>
                    <button type="submit" class="btn btn-secondary float-right">Envoyer</button>
                </form>
            </div>
            <div class="col-lg-12 mt-3">
                <div class="text-right">
                    <small class="text-dark text-dark d-block">Copyright &copy; <script>
                            document.write(new Date().getFullYear())
                        </script> <a href="http://arato.mg" target="_blank">ARATO</a>.</span>
                    </small>
                </div>
            </div>
        </div>
    </section>


    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/html.js"></script>
    <script src="assets/js/function.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>

    <script src="assets/js/pages/accueil.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/magnific-popup-options.js"></script>
    <script src="assets/js/sweetalert.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
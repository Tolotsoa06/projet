function afficher_diapo_header(header) {
    return "<div class='slider-item' style='background-image: url(\"" + header.image + "\");'>" +
        "<div class='container'>" +
        "<div class='row slider-text align-items-center justify-content-center'>" +
        "<div class='col-md-8 text-center col-sm-12 element-animate fadeInUp element-animated'>" +
        "<h1>" + header.titre + "</h1>" +
        "<p class='mb-5'>" + header.texte + "</p>" +
        "</div>" +
        "</div>" +
        "</div>" +
        "</div>";
}

function afficher_diapo_actualite(actualite) {
    return "<a href='#' onclick=\"getDetail('" + actualite.id_actualite + "')\" class='item-dishes'>" +
        "<div class='text'>" +
        "<h2 class='dishes-heading'>" + actualite.titre + "</h2>" +
        "</div>" +
        "<img src='" + actualite.image + "' alt='' class='img-fluid'>" +
        "</a>";

}

function afficher_diapo_actualite(actualite) {
    return "<a href='#' onclick=\"getDetail('" + actualite.id_actualite + "')\" class='item-dishes'>" +
        "<div class='text'>" +
        "<h2 class='dishes-heading'>" + actualite.titre + "</h2>" +
        "</div>" +
        "<img src='" + actualite.image + "' alt='' class='img-fluid'>" +
        "</a>";

}

function afficher_actualite(actualite) {
    return "<div class='media border p-3 mb-3'>" +
        "<img src='" + actualite.image + "' alt='Image actualité' class='mr-3 mt-3 rounded-circle' style='width:100px;'>" +
        "<div class='media-body'>" +
        "<h4>" + actualite.titre + "<br><small><i>Publié le " + actualite.date + "</i></small></h4>" +
        "<p class='contenu overflow-ellipsis'>" + actualite.contenu + "</p>" +
        "<a onclick=\"getDetail('" + actualite.id_actualite + "')\" style='cursor : pointer' class='link-actualite float-right'>Voir plus</a>" +
        "</div>" +
        "</div>";
}

function afficher_un_actualite(actualite) {
    return "<div class='media border p-3 mb-3 single-actualite'>" +
        "<img src='" + actualite.image + "' alt='Image actualité' class='mr-3 mt-3'>" +
        "<div class='media-body'>" +
        "<h4>" + actualite.titre + "<br> <small><i>Publié le " + actualite.date + "</i></small></h4>" +
        "<p>" + actualite.contenu + "</p>" +
        "</div>" +
        "</div>";
}

function afficher_all_events(evenement) {
    return "<div class='media border p-3 mb-3 col-md-6 col-sm-12'>" +
        "<img src='" + evenement.image + "' alt='Image Evenement' class='mr-3 mt-3'>" +
        "<div class='media-body'>" +
        "<h4>" + evenement.titre + "<br> <small>du <i>" + evenement.date_debut + " au " + evenement.date_fin + "</i></small></h4>" +
        "<p>" + evenement.description + "</p>" +
        "</div>" +
        "</div>";
}

function afficher_partenaire(partenaire) {
    return "<a href='" + partenaire.site_web + "' target='_blank' class='item-dishes'>" +
        "<div class='text'>" +
        "<h2 class='dishes-heading'>" + partenaire.nom + "</h2>" +
        "</div>" +
        "<img src='" + partenaire.image + "' alt='' class='img-fluid'>" +
        "</a>";
}
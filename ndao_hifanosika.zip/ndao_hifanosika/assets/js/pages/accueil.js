(function($) {
    'use strict';
    getHeader();
    getActualite();
    getAllpartenaire();
})(jQuery);

$("#formContact").on('submit', function() {
    let email = $("#email").val();
    let nom = $("#nom").val();
    let sujet = $("#sujet").val();
    let message = $("#message").val();
    if (email && nom && sujet && message) {
        let form = $(this);
        $.ajax({
            url: 'action/mail.php',
            type: 'POST',
            data: form.serialize(),
            success: function(data) {
                swal({
                    icon: 'success',
                    title: 'Merci de nous avoir contacté!',
                    text: 'Nous allons repondre votre message dès que possible'
                });
            }
        })
    } else {
        swal({
            icon: 'error',
            text: 'Veuillez completer tous les champs'
        });
    }
    return false;
});
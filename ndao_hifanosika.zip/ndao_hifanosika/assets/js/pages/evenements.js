(function($) {
    'use strict';
    getHeader();
    getAllEvents();
})(jQuery);
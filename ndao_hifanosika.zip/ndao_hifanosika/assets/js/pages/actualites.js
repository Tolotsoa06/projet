(function($) {
    'use strict';
    getHeader();
    getAllActualite();
})(jQuery);
(function($) {
    'use strict';
    getHeader();
    getOneActualite();
})(jQuery);
function getActualite() {
    $.ajax({
        url: 'action/actualite.php',
        type: 'POST',
        data: {
            getActualite: 1
        },
        dataType: 'json',
        success: function(response) {
            var actualite = "";
            response.forEach(element => {
                actualite += afficher_diapo_actualite(element);
            });
            $(".actualite-slider").html(actualite);
        }
    });
}


function getHeader() {
    $.ajax({
        url: 'action/diapo_header.php',
        type: 'POST',
        data: {
            getHeader: 1
        },
        dataType: 'json',
        success: function(response) {
            var header = "";
            response.forEach(element => {
                header += afficher_diapo_header(element);
            });
            $(".home-slider").html(header);
        }
    });
}

function getAllActualite() {
    $.ajax({
        url: 'action/actualite.php',
        type: 'POST',
        data: {
            getAll: 1
        },
        dataType: 'json',
        success: function(response) {
            var actualite = "";
            response.forEach(element => {
                actualite += afficher_actualite(element);
            });
            $("#actualite").html(actualite);
        }
    });
}

function getDetail(id) {
    window.localStorage.setItem('id_actualite', id);
    window.location.href = "actualite.php";
}

function getOneActualite() {
    $.ajax({
        url: 'action/actualite.php',
        type: 'POST',
        data: {
            getOne: 1,
            id_actualite: window.localStorage.getItem('id_actualite')
        },
        dataType: 'json',
        success: function(response) {
            $("#actualite").html(afficher_un_actualite(response));
        }
    });
}

function getAllEvents() {
    $.ajax({
        url: 'action/evenement.php',
        type: 'POST',
        data: {
            getAll: 1
        },
        dataType: 'json',
        success: function(response) {
            var event = "";
            response.forEach(element => {
                event += afficher_all_events(element);
            });
            $("#evenements").html(event);
        }
    })
}

function getAllpartenaire() {
    $.ajax({
        url: 'action/partenaire.php',
        type: 'POST',
        data: {
            getAll: 1
        },
        dataType: 'json',
        success: function(data) {
            var partenaire = "";
            data.forEach(element => {
                partenaire += afficher_partenaire(element);
            });
            $(".centernonloop").append(partenaire);
        }
    })
}